package com.example.paypointretailer.Model

data class Favourite(
    var isSelected : Boolean =false,
    var name : String?=null,
    var subTitle : String?=null
)

