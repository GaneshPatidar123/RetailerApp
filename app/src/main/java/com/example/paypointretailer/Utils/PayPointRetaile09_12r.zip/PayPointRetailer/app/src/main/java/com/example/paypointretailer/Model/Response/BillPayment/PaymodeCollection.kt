package com.example.paypointretailer.Model.Response.BillPayment

data class PaymodeCollection(
    var PaymodeAlias :Int?,
    var Paymode : String
)
