package com.example.paypointretailer.Model.Response

import java.io.Serializable

data class ListGiftVoucherResponse(
    var Name :String?,
    var Key : String?,
    var Category :String?,
):Serializable
