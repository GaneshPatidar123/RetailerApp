package com.example.paypointretailer.Model.Response.MainResponse

data class CircleCollection(
    var CircleID: Int?,
    var Operator: String?,
    var Circle: String?,
    var ProductAliasID: Int?,
)

