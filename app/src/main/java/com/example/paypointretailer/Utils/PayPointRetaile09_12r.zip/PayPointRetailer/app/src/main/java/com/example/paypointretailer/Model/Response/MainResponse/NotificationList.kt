package com.example.paypointretailer.Model.Response.MainResponse

import java.io.Serializable

data class NotificationList(
    var id: Int?,
    var text: String?,
    var ntitle: String?,
    var createdon: String?,
    var domainid: Int?,
):Serializable
