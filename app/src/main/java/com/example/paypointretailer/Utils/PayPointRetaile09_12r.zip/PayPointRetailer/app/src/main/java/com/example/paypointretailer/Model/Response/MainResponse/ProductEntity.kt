package com.example.paypointretailer.Model.Response.MainResponse

data class ProductEntity(
    var ServiceTypeId: Int?,
    var ServiceType: String?,
    var DomainId: Int?,
    var Domain: String?,
    var ProductId: Int?,
    var Product: String?,
)
