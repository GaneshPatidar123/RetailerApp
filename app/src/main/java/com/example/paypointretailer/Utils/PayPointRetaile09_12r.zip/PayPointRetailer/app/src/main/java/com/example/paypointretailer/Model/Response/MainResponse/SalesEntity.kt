package com.example.paypointretailer.Model.Response.MainResponse

data class SalesEntity(
    var DailyNet: String?,
    var WeekNet: String?,
    var MonthNet: Double?,
    var YearNet: String?
)
