package com.example.paypointretailer.Model.Response.MoneyTransfer

data class Config(
    var ICICI :ConfigData?,
    var PayTm :ConfigData?,
    var ICICINEW :ConfigData?,
    var NSDL :ConfigData?,
    var CHANNEL5 :ConfigData?,
    var PreferChannel :ConfigData?,
)
