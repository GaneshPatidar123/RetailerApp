package com.example.paypointretailer.Model.Response.MoneyTransfer

data class ConfigData(
    var fCount :Int?,
    var fType :Int?,
)
