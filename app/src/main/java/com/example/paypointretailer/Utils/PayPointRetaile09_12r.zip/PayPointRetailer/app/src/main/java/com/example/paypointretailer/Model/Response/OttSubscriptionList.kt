package com.example.paypointretailer.Model.Response

import java.io.Serializable

data class OttSubscriptionList(
    var name :String?,
    var id:String?
):Serializable
