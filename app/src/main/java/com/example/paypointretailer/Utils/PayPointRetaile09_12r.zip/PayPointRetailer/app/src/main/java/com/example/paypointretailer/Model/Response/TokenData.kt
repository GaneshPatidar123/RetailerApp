package com.example.paypointretailer.Model.Response

data class TokenData(
    var access_token : String?,
    var expires_in : String?
)
