package com.example.paypointretailer.Model.Response

data class VpaListData(
    var BusinessId : Int?,
    var PayerName : String?,
    var PayerMobile :String?,
    var PayerVA :String?,
    var Status :Int?,
    var Remarks :String?,
    var Id :Int,
)
