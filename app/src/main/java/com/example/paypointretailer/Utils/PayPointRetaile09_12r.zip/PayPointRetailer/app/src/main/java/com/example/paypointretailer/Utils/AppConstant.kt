package com.example.paypointretailer.Utils

import android.os.Bundle

object AppConstant {
    const val IS_FROM = "isFrom"
    const val SIGN_UP_REQUEST = "signUpRequest"
    const val DATA = "data"
}