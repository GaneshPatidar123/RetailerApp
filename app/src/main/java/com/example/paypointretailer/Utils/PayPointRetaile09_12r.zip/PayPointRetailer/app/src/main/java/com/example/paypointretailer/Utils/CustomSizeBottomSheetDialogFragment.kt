package com.example.paypointretailer.Utils

import android.app.Dialog
import androidx.fragment.app.DialogFragment

class CustomSizeBottomSheetDialogFragment : DialogFragment() {

}