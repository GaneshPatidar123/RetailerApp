package com.example.paypointretailer.Utils

interface OnChangeTabListner {
    fun onChnges()
}