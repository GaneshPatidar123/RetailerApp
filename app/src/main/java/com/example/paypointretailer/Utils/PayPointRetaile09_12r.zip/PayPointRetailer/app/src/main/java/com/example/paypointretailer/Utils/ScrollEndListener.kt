package com.example.paypointretailer.Utils

interface ScrollEndListener {
    fun onScrollEnd()
}