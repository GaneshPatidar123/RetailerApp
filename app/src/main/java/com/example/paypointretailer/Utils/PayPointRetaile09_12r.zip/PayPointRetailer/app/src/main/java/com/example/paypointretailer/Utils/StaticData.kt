package com.example.paypointretailer.Utils

object StaticData {
    val currentVersion ="100164"
    var aedSecreteKey ="nH7yJ2sT5zN3tX6m"

}