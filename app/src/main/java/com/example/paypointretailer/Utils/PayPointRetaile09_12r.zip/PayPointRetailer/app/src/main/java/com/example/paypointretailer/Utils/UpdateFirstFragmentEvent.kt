package com.example.paypointretailer.Utils

data class UpdateFirstFragmentEvent(val message: String)
