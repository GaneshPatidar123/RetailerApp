package com.example.paypointretailer.View.Activity.MoneyTransfer

import android.content.SharedPreferences
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.activity.viewModels
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModel
import com.example.paypointretailer.Base.BaseActivity
import com.example.paypointretailer.Extention.showErrorMessage
import com.example.paypointretailer.Model.Request.GetRemitterDetailsRrquest
import com.example.paypointretailer.Model.Request.LoginRequest
import com.example.paypointretailer.R
import com.example.paypointretailer.Utils.AppUtils
import com.example.paypointretailer.Utils.EncryptionUtils
import com.example.paypointretailer.Utils.Resource
import com.example.paypointretailer.Utils.StaticData
import com.example.paypointretailer.ViewModel.GetLoginDataStateEvent
import com.example.paypointretailer.ViewModel.GetMoneyTransferStateEvent
import com.example.paypointretailer.ViewModel.LoginViewModel
import com.example.paypointretailer.ViewModel.MoneyTransferViewModel
import com.example.paypointretailer.databinding.ActivityAepsServicesBinding
import com.example.paypointretailer.databinding.ActivityMoneyTransferBinding
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class MoneyTransferActivity :
    BaseActivity<ActivityMoneyTransferBinding>(R.layout.activity_money_transfer) {
    @Inject
    lateinit var sharedPrefs: SharedPreferences
    private val viewModel: MoneyTransferViewModel by viewModels()
    private  var PreferredMode ="IMPS"
    override fun setUpViews() {
        binding.toolBar.tvTitle.text = getString(R.string.bc_money_transfer)
        binding.radioGroup.check(R.id.rvIMPS)

    }

    override fun setUpListeners() {
        binding.toolBar.ivBack.setOnClickListener {
            onBackPressed()
        }
        binding.radioGroup.setOnCheckedChangeListener { group, checkedId ->
            when (checkedId) {
                R.id.rvIMPS -> {
                    PreferredMode = "IMPS"
                }
                R.id.rvNEFT -> {
                    PreferredMode = "NEFT"
                }
            }
        }
        binding.tvCheck.setOnClickListener {
            if (binding.edtNumber.text.isNullOrEmpty()) {
                 showErrorMessage(this,"Please enter mobile number")
            } else if (binding.edtNumber.text!!.length < 10) {
                showErrorMessage(this,"Please enter valid mobile number")
            } else {
                if (AppUtils.hasInternet(this)) {
                    val request: GetRemitterDetailsRrquest = GetRemitterDetailsRrquest(
                        MobileNo = binding.edtNumber.text.toString(),
                        PreferredMode = PreferredMode,
                        ForcedChannelRefresh = "2",
                        Token = pref.getData()?.access_token.toString(),
                        key = pref.getData()?.BusinessId.toString()
                    )
                    viewModel.getDetails(GetMoneyTransferStateEvent.getDetails, request)
                } else {
                    showErrorMessage(
                        this,
                        getString(R.string.please_check_internet_connection)
                    )
                }
            }
        }
    }

    override fun setUpObservers() {
        viewModel.dataStateDetails.observe(this, Observer {  dataState ->
            when (dataState) {
                is Resource.Success -> {
                   // hideProgressDialog()
                    val userData = dataState.data

                    val request: GetRemitterDetailsRrquest = GetRemitterDetailsRrquest(
                        MobileNo = binding.edtNumber.text.toString(),
                        PreferredMode = null,
                        ForcedChannelRefresh = null,
                        Token = pref.getData()?.access_token.toString(),
                        key = pref.getData()?.BusinessId.toString()
                    )
                    viewModel.getBeneficialList(GetMoneyTransferStateEvent.getBeneficial, request)

                }

                is Resource.Error -> {
                    hideProgressDialog()
                    showErrorMessage(this, dataState.message)
                    //  notifyUser(dataState.message)
                }

                is Resource.Loading -> {
                    showProgressDialog()
                }
            }

        })

        viewModel.dataStateBeneficial.observe(this, Observer {  dataState ->
            when (dataState) {
                is Resource.Success -> {
                     hideProgressDialog()
                    val userData = dataState.data

                }

                is Resource.Error -> {
                    hideProgressDialog()
                    showErrorMessage(this, dataState.message)
                    //  notifyUser(dataState.message)
                }

                is Resource.Loading -> {
                    showProgressDialog()
                }
            }

        })
    }
}