package com.example.paypointretailer.View.Activity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.paypointretailer.R

class SplashActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)
    }
}