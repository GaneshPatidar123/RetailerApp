package com.example.paypointretailer.View.Fragement

import androidx.fragment.app.Fragment


class StepOneFragment : Fragment() {

   /* private lateinit var binding: LayoutStepOneBinding

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = LayoutStepOneBinding.inflate(layoutInflater)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        //  setupData()
    }*/
}